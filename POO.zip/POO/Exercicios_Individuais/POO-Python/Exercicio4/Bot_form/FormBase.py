# FormBase.py
class FormBase:
    def __init__(self):
        pass

    def fill_form(self):
        raise NotImplementedError("This method should be overridden in subclasses")