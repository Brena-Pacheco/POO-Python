#!/bin/bash

zip -r "Bot_form.zip" * -x "Bot_form.zip"