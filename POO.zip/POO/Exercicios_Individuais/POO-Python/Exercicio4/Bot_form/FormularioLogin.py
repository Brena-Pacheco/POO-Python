# FormularioLogin.py
from FormBase import FormBase

class FormularioLogin(FormBase):
    def __init__(self, username, password):
        super().__init__()
        self.username = username  # O nome do usuário
        self.password = password  # A senha
        self.url = "http://localhost:8000/login.html"  # URL do formulário de login

    def fill_form(self):
        return {
            "Username": self.username,
            "Password": self.password
        }

    def abrir_formulario(self):
        # Este método pode estar vazio ou pode ser utilizado para alguma lógica específica
        pass
