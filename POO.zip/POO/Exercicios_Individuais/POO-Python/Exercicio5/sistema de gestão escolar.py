# Classe Aluno
class Aluno:
    def __init__(self, nome, matricula):
        if not nome:
            raise ValueError("O nome do aluno não pode estar vazio.")
        if matricula <= 0:
            raise ValueError("A matrícula deve ser um número positivo.")
            
        self.nome = nome
        self.matricula = matricula

    def mostrar_info(self):
        """Exibe as informações do aluno."""
        print(f"Nome: {self.nome}, Matrícula: {self.matricula}")

    def __str__(self):
        """Representação em string do objeto Aluno."""
        return f"{self.nome} (Matrícula: {self.matricula})"


# Classe Curso
class Curso:
    def __init__(self, nome, codigo):
        if not nome or not codigo:
            raise ValueError("O nome e o código do curso não podem estar vazios.")
            
        self.nome = nome
        self.codigo = codigo
        self.alunos = []

    def adicionar_aluno(self, aluno):
        """Adiciona um aluno ao curso."""
        if aluno not in self.alunos:
            self.alunos.append(aluno)
        else:
            print(f"O aluno {aluno.nome} já está matriculado neste curso.")

    def mostrar_alunos(self):
        """Lista todos os alunos matriculados no curso."""
        print(f"Alunos matriculados no curso {self.nome}:")
        if not self.alunos:
            print("Nenhum aluno matriculado.")
        else:
            for aluno in self.alunos:
                aluno.mostrar_info()

    def __str__(self):
        """Representação em string do objeto Curso."""
        return f"{self.nome} (Código: {self.codigo})"


# Classe Escola
class Escola:
    def __init__(self, nome):
        if not nome:
            raise ValueError("O nome da escola não pode estar vazio.")
            
        self.nome = nome
        self.cursos = []

    def adicionar_curso(self, curso):
        """Adiciona um curso à escola."""
        if curso not in self.cursos:
            self.cursos.append(curso)
        else:
            print(f"O curso {curso.nome} já está oferecido na escola.")

    def mostrar_cursos(self):
        """Lista todos os cursos e os alunos matriculados em cada um."""
        print(f"Cursos oferecidos na escola {self.nome}:")
        if not self.cursos:
            print("Nenhum curso disponível.")
        else:
            for curso in self.cursos:
                curso.mostrar_alunos()

    def __str__(self):
        """Representação em string do objeto Escola."""
        return self.nome


# Função para criar e gerenciar a escola
def main():
    try:
        # Criar a escola
        nome_escola = input("Digite o nome da escola: ")
        escola = Escola(nome_escola)

        # Adicionar cursos à escola
        while True:
            nome_curso = input("Digite o nome do curso (ou 'sair' para finalizar): ")
            if nome_curso.lower() == 'sair':
                break
            codigo_curso = input("Digite o código do curso: ")
            curso = Curso(nome_curso, codigo_curso)

            # Adicionar alunos ao curso
            while True:
                nome_aluno = input("Digite o nome do aluno (ou 'sair' para finalizar): ")
                if nome_aluno.lower() == 'sair':
                    break
                matricula_aluno = int(input("Digite a matrícula do aluno: "))
                aluno = Aluno(nome_aluno, matricula_aluno)
                curso.adicionar_aluno(aluno)

            escola.adicionar_curso(curso)

        # Exibindo informações da escola, cursos e alunos
        escola.mostrar_cursos()

    except ValueError as e:
        print(f"Erro: {e}")


# Executando a função principal
if __name__ == "__main__":
    main()
