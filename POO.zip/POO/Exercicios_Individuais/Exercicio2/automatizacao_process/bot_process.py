from botcity.web import WebBot, Browser, By
from webdriver_manager.chrome import ChromeDriverManager
import os
import time

# Classe Produto
class Produto:
    def __init__(self, nome, preco, quantidade):
        self.nome = nome
        self.preco = preco
        self.quantidade = quantidade

    def exibir_informacoes(self):
        print(f"Nome: {self.nome}")
        print(f"Preço: {self.preco:.2f}")
        print(f"Quantidade: {self.quantidade}")

def preencher_formulario(bot, produto):
    try:
        bot.browse("http://localhost:8000/formulario_produto.html")  # URL do formulário
        bot.wait(5000)  # Espera 5 segundos para garantir que a página carregou

        # Preencher os campos do formulário
        bot.find_element(By.ID, "nome").send_keys(produto.nome)  # Preencher o campo nome
        bot.find_element(By.ID, "preco").send_keys(str(produto.preco))  # Preencher o campo preço
        bot.find_element(By.ID, "quantidade").send_keys(str(produto.quantidade))  # Preencher o campo quantidade

        # Clicar no botão de cadastrar
        bot.find_element(By.XPATH, "//input[@value='Cadastrar Produto']").click()  # Clica no botão

        print("Formulário preenchido com sucesso!")

    except Exception as e:
        print(f"Ocorreu um erro ao preencher o formulário: {e}")
        time.sleep(5)  # Mantenha o navegador aberto para visualizar o erro

def atualizar_arquivo_txt(produto):
    arquivo = "produtos.txt"
    # Verifica se o arquivo já existe
    if os.path.exists(arquivo):
        # Se o arquivo existe, atualiza o conteúdo
        with open(arquivo, "a") as f:
            f.write(f"Nome: {produto.nome}, Preço: {produto.preco:.2f}, Quantidade: {produto.quantidade}\n")
    else:
        # Se não existe, cria um novo arquivo
        with open(arquivo, "w") as f:
            f.write("Produtos:\n")
            f.write(f"Nome: {produto.nome}, Preço: {produto.preco:.2f}, Quantidade: {produto.quantidade}\n")

def main():
    produto = Produto("Caneta", 1.5, 100)
    produto.exibir_informacoes()

    bot = WebBot()
    bot.driver_path = ChromeDriverManager().install()  # Instala o ChromeDriver automaticamente
    preencher_formulario(bot, produto)

    # Atualiza ou cria o arquivo .txt
    atualizar_arquivo_txt(produto)

    # Espera um pouco antes de fechar o navegador
    bot.wait(5000)  # Mantenha o navegador aberto por mais 5 segundos
    bot.stop_browser()  # Fechar o navegador

if __name__ == "__main__":
    main()
