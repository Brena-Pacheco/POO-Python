class Livro:
    def __init__(self, titulo, autor):
        self.titulo = titulo
        self.autor = autor
        self.disponivel = True

    def emprestar(self):
        if self.disponivel:
            self.disponivel = False
            print(f'O livro "{self.titulo}" foi emprestado.')
        else:
            print(f'O livro "{self.titulo}" não está disponível.')

    def devolver(self):
        self.disponivel = True
        print(f'O livro "{self.titulo}" foi devolvido.')

    def mostrar_info(self):
        disponivel_str = "Sim" if self.disponivel else "Não"
        print(f'Título: {self.titulo}, Autor: {self.autor}, Disponível: {disponivel_str}')


class Livraria:
    def __init__(self):
        self.livros = []

    def adicionar_livro(self, livro):
        self.livros.append(livro)
        print(f'Livro "{livro.titulo}" adicionado ao inventário.')

    def emprestar_livro(self, titulo):
        for livro in self.livros:
            if livro.titulo == titulo:
                livro.emprestar()
                return
        print(f'Livro "{titulo}" não encontrado no inventário.')

    def mostrar_inventario(self):
        print("Inventário de Livros:")
        for livro in self.livros:
            livro.mostrar_info()


# Exemplo de uso
livraria = Livraria()

# Adicionando livros
livro1 = Livro("O Senhor dos Anéis", "J.R.R. Tolkien")
livro2 = Livro("1984", "George Orwell")

livraria.adicionar_livro(livro1)
livraria.adicionar_livro(livro2)

# Emprestando um livro
livraria.emprestar_livro("1984")

# Mostrando inventário
livraria.mostrar_inventario()

# Devolvendo um livro
livro2.devolver()

# Mostrando inventário novamente
livraria.mostrar_inventario()
