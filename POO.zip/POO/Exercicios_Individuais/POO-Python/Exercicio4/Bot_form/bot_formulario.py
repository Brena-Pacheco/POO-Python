# Import 
from FormularioContato import FormularioContato
from FormularioLogin import FormularioLogin
import time

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

# Import for the Web Bot
from botcity.web import WebBot, Browser, By  # Importando By
from webdriver_manager.chrome import ChromeDriverManager
import csv

class BotFormulario(WebBot):
    def action(self, execution=None):
        # Ler dados do CSV
        dados = self.ler_dados_csv('dados_formularios.csv')

        for dado in dados:
            # Criar instâncias dos formulários com os dados lidos
            form_contato = {
                "nome": dado['nome'],
                "email": dado['email'],
                "mensagem": dado['mensagem']
            }
            form_login = {
                "usuario": dado['usuario'],
                "senha": dado['senha']
            }

            # Configurar o driver do Chrome
            self.driver_path = ChromeDriverManager().install()

            # Abrir o formulário de contato no navegador Chrome
            self.browse("http://localhost:8000/formulario.html")  # Usando a URL
            time.sleep(5)  # Tempo de espera

            # Preencher o formulário de contato
            self.preencher_formulario_contato(form_contato)

            # Abrir o formulário de login no navegador Chrome
            self.browse("http://localhost:8000/login.html")  # Usando a URL
            time.sleep(5)  # Tempo de espera

            # Preencher o formulário de login
            self.preencher_formulario_login(form_login)

    def ler_dados_csv(self, arquivo_csv):
        dados = []
        with open(arquivo_csv, mode='r', newline='', encoding='utf-8') as file:
            leitor = csv.DictReader(file)
            for linha in leitor:
                dados.append(linha)
        return dados

    def preencher_formulario_contato(self, form):
        self.execute_javascript(f'document.getElementById("nome").value = "{form["nome"]}";')
        self.execute_javascript(f'document.getElementById("email").value = "{form["email"]}";')
        self.execute_javascript(f'document.getElementById("mensagem").value = "{form["mensagem"]}";')
        # Simula o envio do formulário
        self.execute_javascript('document.getElementById("contatoForm").submit();')

    def preencher_formulario_login(self, form):
        # Aguarda até que o campo de username esteja disponível
        while not self.find_element('username', By.ID):
            time.sleep(1)
            print('Aguardando o campo de usuário estar disponível...')

        self.execute_javascript(f'document.getElementById("username").value = "{form["usuario"]}";')

        # Aguarda até que o campo de password esteja disponível
        while not self.find_element('password', By.ID):
            time.sleep(1)
            print('Aguardando o campo de senha estar disponível...')
        
        self.execute_javascript(f'document.getElementById("password").value = "{form["senha"]}";')
        # Simula o envio do formulário de login
        self.execute_javascript('document.getElementById("loginForm").submit();')  # Usando o ID do formulário

if __name__ == "__main__":
    BotFormulario.main()
