#!/bin/bash

zip -r "automatizacao_process.zip" * -x "automatizacao_process.zip"