# produto.py
class Produto:
    def __init__(self, nome, preco, quantidade):
        self.nome = nome
        self.preco = preco
        self.quantidade = quantidade

    def exibir_informacoes(self):
        print(f"Nome: {self.nome}")
        print(f"Preço: {self.preco:.2f}")
        print(f"Quantidade: {self.quantidade}")

    def atualizar_informacoes(self, nome=None, preco=None, quantidade=None):
        if nome:
            self.nome = nome
        if preco is not None:
            self.preco = preco
        if quantidade is not None:
            self.quantidade = quantidade
