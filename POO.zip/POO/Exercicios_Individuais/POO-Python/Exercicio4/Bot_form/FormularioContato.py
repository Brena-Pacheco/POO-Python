# FormularioContato.py
from FormBase import FormBase

class FormularioContato(FormBase):
    def __init__(self, nome, email, mensagem):
        super().__init__()
        self.nome = nome
        self.email = email
        self.mensagem = mensagem
        self.url = "http://localhost:8000/formulario.html"  # URL do formulário de contato

    def fill_form(self):
        return {
            "Nome": self.nome,
            "Email": self.email,
            "Mensagem": self.mensagem
        }

    def abrir_formulario(self):
        # Este método pode estar vazio ou pode ser utilizado para alguma lógica específica
        pass

