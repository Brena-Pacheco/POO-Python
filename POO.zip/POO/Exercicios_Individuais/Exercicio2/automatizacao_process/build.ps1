$exclude = @("venv", "automatizacao_process.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "automatizacao_process.zip" -Force