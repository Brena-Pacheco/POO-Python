class Pagamento:
    def processar_pagamento(self):
        """Método que não faz nada, será sobrescrito nas subclasses."""
        pass


class PagamentoCartaoCredito(Pagamento):
    def __init__(self, numero_cartao):
        self.numero_cartao = numero_cartao

    def processar_pagamento(self):
        """Processa o pagamento com cartão de crédito."""
        print(f"Pagamento com cartão de crédito {self.numero_cartao} processado.")


class PagamentoBoleto(Pagamento):
    def __init__(self, codigo_boleto):
        self.codigo_boleto = codigo_boleto

    def processar_pagamento(self):
        """Processa o pagamento com boleto."""
        print(f"Pagamento com boleto {self.codigo_boleto} processado.")


class PagamentoPix(Pagamento):
    def __init__(self, chave_pix):
        self.chave_pix = chave_pix

    def processar_pagamento(self):
        """Processa o pagamento via Pix."""
        print(f"Pagamento via Pix com chave {self.chave_pix} processado.")


class SistemaPagamentos:
    def __init__(self):
        self.historico_pagamentos = []

    def processar(self, pagamento: Pagamento):
        """Processa um pagamento, independentemente do tipo."""
        pagamento.processar_pagamento()
        self.historico_pagamentos.append(pagamento)

    def exibir_historico(self):
        """Exibe todos os pagamentos processados."""
        print("\nHistórico de Pagamentos:")
        if not self.historico_pagamentos:
            print("Nenhum pagamento processado.")
        else:
            for pagamento in self.historico_pagamentos:
                tipo_pagamento = type(pagamento).__name__
                print(f"{tipo_pagamento} processado.")

    @staticmethod
    def validar_numero_cartao(numero_cartao):
        """Valida o número do cartão de crédito (simples)."""
        return len(numero_cartao) == 16 and numero_cartao.isdigit()

    @staticmethod
    def validar_codigo_boleto(codigo_boleto):
        """Valida o código do boleto (simples)."""
        return len(codigo_boleto) >= 10

    @staticmethod
    def validar_chave_pix(chave_pix):
        """Valida a chave Pix (simples)."""
        return len(chave_pix) >= 1


# Função principal para interação com o usuário
def main():
    sistema = SistemaPagamentos()

    while True:
        print("\nSistema de Pagamentos")
        print("1. Pagamento com Cartão de Crédito")
        print("2. Pagamento com Boleto")
        print("3. Pagamento via Pix")
        print("4. Exibir Histórico de Pagamentos")
        print("5. Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            numero_cartao = input("Digite o número do cartão de crédito (16 dígitos): ")
            if sistema.validar_numero_cartao(numero_cartao):
                pagamento = PagamentoCartaoCredito(numero_cartao)
                sistema.processar(pagamento)
            else:
                print("Número de cartão inválido. Certifique-se de que possui 16 dígitos.")

        elif opcao == '2':
            codigo_boleto = input("Digite o código do boleto (mínimo 10 caracteres): ")
            if sistema.validar_codigo_boleto(codigo_boleto):
                pagamento = PagamentoBoleto(codigo_boleto)
                sistema.processar(pagamento)
            else:
                print("Código do boleto inválido. Certifique-se de que possui pelo menos 10 caracteres.")

        elif opcao == '3':
            chave_pix = input("Digite a chave Pix (mínimo 1 caractere): ")
            if sistema.validar_chave_pix(chave_pix):
                pagamento = PagamentoPix(chave_pix)
                sistema.processar(pagamento)
            else:
                print("Chave Pix inválida. Certifique-se de que possui pelo menos 1 caractere.")

        elif opcao == '4':
            sistema.exibir_historico()

        elif opcao == '5':
            print("Saindo do sistema.")
            break

        else:
            print("Opção inválida. Tente novamente.")


# Executando a função principal
if __name__ == "__main__":
    main()
